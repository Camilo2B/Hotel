package co.edu.uniquindio.poo.hoteeeel;

public interface Consumir {

    void consumir();

}
