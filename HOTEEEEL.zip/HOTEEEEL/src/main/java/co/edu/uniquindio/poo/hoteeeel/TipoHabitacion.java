package co.edu.uniquindio.poo.hoteeeel;

public enum TipoHabitacion {
    SIMPLE,
    DOBLE,
    SUIT,
}
