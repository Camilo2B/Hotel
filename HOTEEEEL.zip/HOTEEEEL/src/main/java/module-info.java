module co.edu.uniquindio.poo.hoteeeel {
    requires javafx.controls;
    requires javafx.fxml;


    opens co.edu.uniquindio.poo.hoteeeel to javafx.fxml;
    exports co.edu.uniquindio.poo.hoteeeel;
}